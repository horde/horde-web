/*
 * Copyright (C) 2000 Loic Dachary
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include <stdio.h>
#include <krb5.h>

#include <phpkrb5.h>

static krb5_context kcontext;
static krb5_creds my_creds;

int phpkrb5_login(char* name, char* password)
{
  krb5_error_code retval;
  krb5_principal me;
  krb5_ccache xtra_creds = NULL;

  retval = krb5_init_secure_context(&kcontext);
  if (retval) {
    fprintf(stderr, "%d while initializing krb5", retval);
    return KRB5_NOTOK;
  }

  if ((retval = krb5_parse_name(kcontext, name, &me))) {
    fprintf(stderr, "%d when parsing name %s",retval,name);
    return KRB5_NOTOK;
  }

  if ((retval = krb5_get_init_creds_password(kcontext, &my_creds, me, password,
					     krb5_prompter_posix, NULL,
					     0, NULL, NULL))) {
    if (retval == KRB5KRB_AP_ERR_BAD_INTEGRITY)
      return KRB5_BAD_PASSWORD;
    else if (retval == KRB5KDC_ERR_C_PRINCIPAL_UNKNOWN)
      return KRB5_BAD_USER;
    else
      fprintf(stderr, "%d while getting initial credentials", retval);
    return KRB5_NOTOK;
  }
  if ((retval = krb5_verify_init_creds(kcontext, &my_creds, NULL,
				       NULL, &xtra_creds,
				       NULL))) {
    return KRB5_BAD_PASSWORD;
  }
  if (xtra_creds)
    krb5_cc_destroy(kcontext, xtra_creds);

  return KRB5_OK;
}
