/*
 * Copyright (C) 2000 Loic Dachary, Andreas Hochsteger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
/* $Id: php4_unac.c,v 1.2 2000/12/23 10:52:54 loic Exp $ */

#if USE_PHP == 4

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"

#include "phpkrb5.h"

static PHP_FUNCTION(krb5_login);
static PHP_MINIT_FUNCTION(krb5);
static PHP_MSHUTDOWN_FUNCTION(krb5);
static PHP_FUNCTION(krb5_login);
static PHP_MINFO_FUNCTION(krb5);
zend_module_entry *get_module(void);

/* Every user visible function must have an entry in krb5_functions[].
*/
function_entry krb5_functions[] = {
	PHP_FE(krb5_login,	NULL)
	{NULL, NULL, NULL}	/* Must be the last line in krb5_functions[] */
};

zend_module_entry krb5_module_entry = {
        STANDARD_MODULE_HEADER,
	"krb5",
	krb5_functions,
	PHP_MINIT(krb5),
	PHP_MSHUTDOWN(krb5),
	NULL,
	NULL,
	PHP_MINFO(krb5),
        NO_VERSION_YET,
	STANDARD_MODULE_PROPERTIES
};

ZEND_GET_MODULE(krb5)

static PHP_MINIT_FUNCTION(krb5)
{
	REGISTER_LONG_CONSTANT("KRB5_OK", KRB5_OK, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("KRB5_NOTOK", KRB5_NOTOK, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("KRB5_BAD_PASSWORD", KRB5_BAD_PASSWORD, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("KRB5_BAD_USER", KRB5_BAD_USER, CONST_CS | CONST_PERSISTENT);
	return SUCCESS;
}

static PHP_MSHUTDOWN_FUNCTION(krb5)
{
	return SUCCESS;
}

static PHP_MINFO_FUNCTION(krb5)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "krb5 support", "enabled");
	php_info_print_table_end();
	php_info_print_box_start(0);
	PUTS("Validate kerberos5 login. Usage krb5_login(user, password).
Returns KRB5_OK if user and password match.
Returns KRB5_BAD_PASSWORD if wrong password.
Returns KRB5_BAD_USER if user invalid.
Returns KRB5_NOTOK on error.");
	php_info_print_box_end();
}

/* {{{ proto int krb5_login(string charset, string in)
    */
static PHP_FUNCTION(krb5_login)
{
	zval **user, **password;
	int result;

	if (ZEND_NUM_ARGS() != 2 || zend_get_parameters_ex(2, &user, &password) == FAILURE){
		WRONG_PARAM_COUNT;
	}

	convert_to_string(*user);
	convert_to_string(*password);

	if((result = phpkrb5_login((*user)->value.str.val,
							   (*password)->value.str.val)) < 0) {
		zend_error(E_WARNING, "krb5_login: failed %s", strerror(errno));
		RETURN_FALSE;
	}

	RETURN_LONG((long)result);
}
/* }}} */

#endif /* USE_PHP == 4 */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
