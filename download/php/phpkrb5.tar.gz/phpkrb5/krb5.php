<title>krb5 test page</title>

<h3>krb5 test page</h3>

<?

print "<br>user/password match: loic foo -> ";
print krb5_login("loic", "foo") == KRB5_OK ? "OK" : "failed";

print "<br>user exists but password does not match: loic bar -> ";
print krb5_login("loic", "bar") == KRB5_BAD_PASSWORD ? "OK" : "failed";

print "<br>user does not exist: foobar bar -> ";
print krb5_login("foobar", "bar") == KRB5_BAD_USER ? "OK" : "failed";

?>
