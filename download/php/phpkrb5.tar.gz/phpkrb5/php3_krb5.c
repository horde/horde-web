/*
 * Copyright (C) 2000 Loic Dachary, Andreas Hochsteger
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
/* $Id: php3_krb5.c,v 1.3 2000/12/23 10:52:54 loic Exp $ */

#if USE_PHP == 3

#include "dl/phpdl.h"
#include "php.h"
#include "internal_functions.h"

#include <errno.h>

#include "krb5.h"

DLEXPORT php3_module_entry *get_module(void);

static void php3_info_krb5();
static int php3_minit_krb5(INIT_FUNC_ARGS);
static void php3_krb5_string(INTERNAL_FUNCTION_PARAMETERS);

static function_entry krb5_functions[] = {
	{"krb5_string",		php3_krb5_string,	NULL},
	{NULL, NULL, NULL}
};

static void php3_info_krb5() {
	PUTS(
"Strip accents from a string, based on version "KRB5_VERSION".
Usage is krb5_string(charset, string) that returns the string
argument without accents. 
Example: krb5_string(\"iso-8859-1\", \"�t�\") -> \"ete\".
");
}


static int php3_minit_krb5(INIT_FUNC_ARGS) {
	return SUCCESS;
}

static php3_module_entry krb5_module_entry = {
	"KRB5",
	krb5_functions,
	php3_minit_krb5,
	NULL,
	NULL,
	NULL,
	php3_info_krb5,
	STANDARD_MODULE_PROPERTIES
};

DLEXPORT php3_module_entry *get_module(void) { return &krb5_module_entry; }

/* {{{ proto string krb5_string(string charset, string in)
   Returns the krb5cented string */
static void php3_krb5_string(INTERNAL_FUNCTION_PARAMETERS) {
	pval *charset, *in;
	char *str = 0;
	int str_length = 0;
	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &charset, &in) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(charset);
	convert_to_string(in);
	if(krb5_string(charset->value.str.val,
		       in->value.str.val, in->value.str.len,
		       &str, &str_length) < 0) {
	  php3_error(E_WARNING, "krb5_string: failed %s", strerror(errno));
	  RETURN_FALSE;
	}

	RETURN_STRINGL(str, str_length, 1 /* duplicate */);
}
/* }}} */

#endif /* USE_PHP == 3 */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
