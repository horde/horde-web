<?php if ($this->package->package_notes): ?>
 <?php echo _("Notes:") ?><br />
 <p><?php echo htmlspecialchars($this->package->package_notes, ENT_QUOTES, NLS::getCharset()) ?></p>
<?php endif; ?>

<?php $hist = $this->package->history(); if (is_string($hist)) echo $hist; elseif (count($hist)) {
      echo '<h2>' . _("Map") . ' <a href="' . htmlspecialchars($hist[0]->link) . '" target="blank">' . Horde::img('map.png') . '</a></h2><br />';
      foreach ($hist as $item) {
          echo '<h4>' . htmlspecialchars($item->title) . '</h4>';
          echo '<p>' . htmlspecialchars($item->description) . '</p>';
      }
} ?>
