<table class="striped sortable" id="packageList" cellspacing="0">
 <thead>
  <tr>
   <th id="name"<?php if ($this->sortby == 'name') echo $this->sortdirclass ?>><?php echo _("Package") ?></th>
   <th id="date"<?php if ($this->sortby == 'date') echo $this->sortdirclass ?>><?php echo _("Expected Delivery Date") ?></th>
   <th class="nosort"><?php echo _("Tracking Number") ?></th>
  </tr>
 </thead>
 <tbody id="packageListBody">
<?php foreach ($this->packages as $package): ?>
  <tr>
   <td><?php $url = Horde::applicationUrl('package/?p=' . $package->package_id); echo Horde::link($url, '', '', '', Packages::remoteBox(Util::addParameter($url, 'partial', 1))) . $package->package_name ?></a></td>
   <td><?php echo $package->package_exp_date ?></td>
   <td><?php echo $package->package_tracking ?></td>
  </tr>
<?php endforeach; ?>
 </tbody>
</table>
