<?php
/**
 * $Horde: skeleton/index.php,v 1.10 2007/01/02 00:41:55 jan Exp $
 *
 * Copyright 2004-2006 Your Name <you@example.com>
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

@define('SKELETON_BASE', dirname(__FILE__));
$skeleton_configured = (is_readable(SKELETON_BASE . '/config/conf.php') &&
                        is_readable(SKELETON_BASE . '/config/prefs.php'));

if (!$skeleton_configured) {
    require SKELETON_BASE . '/../lib/Test.php';
    Horde_Test::configFilesMissing('Packages', SKELETON_BASE,
                                   array('conf.php', 'prefs.php'));
}

require SKELETON_BASE . '/packages.php';
