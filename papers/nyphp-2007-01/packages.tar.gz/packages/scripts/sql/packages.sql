--
--
CREATE TABLE packages (
    package_id           BIGSERIAL NOT NULL,
    list_id              VARCHAR(100) NOT NULL,
    package_name         VARCHAR(255) NOT NULL,
    package_tracking     VARCHAR(100),
    package_notes        TEXT,
    package_exp_date     INT,
--
    PRIMARY KEY (package_id)
);
