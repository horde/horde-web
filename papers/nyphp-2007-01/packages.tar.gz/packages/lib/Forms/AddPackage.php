<?php
class AddPackageForm extends Horde_Form {

    function AddPackageForm($vars)
    {
        parent::Horde_Form($vars, _("New Package"), 'addpackageform');

        $this->addVariable(_("Name"), 'package_name', 'text', true);
        $this->addVariable(_("Tracking Number"), 'package_tracking', 'text', false);
        $this->addVariable(_("Expected Delivery"), 'package_exp_date', 'monthdayyear', false);
        $this->addVariable(_("Notes"), 'package_notes', 'longtext', false);

        $this->setButtons(_("Save"));
    }

}
