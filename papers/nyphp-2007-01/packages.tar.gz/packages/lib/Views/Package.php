<?php
class PackageView {

    function PackageView($package)
    {
        $this->package = $package;
    }

    function render()
    {
        include PACKAGES_TEMPLATES . '/Package.php';
    }

}
