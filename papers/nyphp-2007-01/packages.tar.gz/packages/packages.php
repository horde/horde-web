<?php
/**
 * $Horde: skeleton/list.php,v 1.9 2007/01/02 00:41:55 jan Exp $
 *
 * Copyright 2004-2006 Your Name <you@example.com>
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

@define('PACKAGES_BASE', dirname(__FILE__));
require_once PACKAGES_BASE . '/lib/base.php';
require_once PACKAGES_BASE . '/lib/Views/PackageList.php';

$title = _("My Packages");

require PACKAGES_TEMPLATES . '/common-header.inc';
require PACKAGES_TEMPLATES . '/menu.inc';

$view = new PackageListView();
echo $view->render();

require $registry->get('templates', 'horde') . '/common-footer.inc';
