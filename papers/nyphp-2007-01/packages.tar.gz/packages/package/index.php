<?php
/**
 * $Horde: $
 *
 * Copyright 2004-2007 Your Name <you@example.com>
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

@define('PACKAGES_BASE', dirname(dirname(__FILE__)));
require_once PACKAGES_BASE . '/lib/base.php';
require_once PACKAGES_BASE . '/lib/Views/Package.php';

$pm = new PackageMapper();
$p = $pm->find((int)Util::getFormData('p'));

$title = $p->package_name;

$partial = Util::getFormData('partial');
if ($partial) {
    echo Packages::closeBox() . '<br /><div id="RB_content">';
} else {
    require PACKAGES_TEMPLATES . '/common-header.inc';
    require PACKAGES_TEMPLATES . '/menu.inc';
}

$view = new PackageView($p);
echo $view->render();

if (!$partial) {
    require $registry->get('templates', 'horde') . '/common-footer.inc';
} else {
   echo '</div>';
}
