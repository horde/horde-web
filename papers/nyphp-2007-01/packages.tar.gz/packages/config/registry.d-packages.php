<?php
$this->applications['packages'] = array(
    'fileroot' => dirname(dirname(dirname(__FILE__))) . '/packages',
    'webroot' => $this->applications['horde']['webroot'] . '/packages',
    'name' => _("Package Tracking"),
    'status' => 'active',
    'menu_parent' => 'organizing',
);
