<?php
/**
 * $Horde: skeleton/config/prefs.php.dist,v 1.3 2003/12/03 20:09:14 chuck Exp $
 *
 * See horde/config/prefs.php for documentation on the structure of this file.
 */

$prefGroups['display'] = array(
    'column' => _("General Options"),
    'label' => _("Display Options"),
    'desc' => _("Change your sorting and display options."),
    'members' => array('sortby', 'sortdir')
);

// user preferred sorting column
$_prefs['sortby'] = array(
    'value' => 'date',
    'locked' => false,
    'shared' => false,
    'type' => 'enum',
    'enum' => array('name' => _("Name"),
                    'date' => _("Delivery Date"),
              ),
    'desc' => _("Sort packages by:")
);

// user preferred sorting direction
$_prefs['sortdir'] = array(
    'value' => 0,
    'locked' => false,
    'shared' => false,
    'type' => 'enum',
    'enum' => array(0 => _("Ascending"),
                    1 => _("Descending")),
    'desc' => _("Sort direction:")
);
