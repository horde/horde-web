<?php

/* Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
//$css['body']['background-color'] = '#FFFFAA';
$css['body']['background'] = 'url(/horde/graphics/fond-horde.png)';
$css['body']['color'] = 'black';
if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px';
}
$css['body']['scrollbar-base-color'] = '#5d5d60';
$css['body']['scrollbar-arrow-color'] = '#ddddff';
$css['html']['scrollbar-base-color'] = '#4d5d60';
$css['html']['scrollbar-arrow-color'] = '#ddddff';

$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = '#993333';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = '#aa6600';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#aa6600';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = '#FF3300';

$css['a.helpitem']['color'] = '#ffffcc';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';

$css['a.widget']['color'] = '#663300';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = '#ee6600';
$css['a.widget:hover']['background-color'] = '#ffffee';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = '#FF3333';
$css['.menu']['background-color'] = '#FFCC00';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

//$css['.header']['color'] = '#996600';
$css['.header']['color'] = '#ffffdd';
$css['.header']['background-color'] = '#FF9900';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = 'white';

$css['.light']['color'] = '#996600';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#ccccee';
$css['.smallheader']['background-color'] = '#ffcc00';
$css['.smallheader']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';

$css['.small']['color'] = '#996600';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';

$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = 'black';
$css['.control']['background-color'] = '#ffffee';
//$css['.control']['background-color'] = '#ffffee';

$css['.item']['color'] = '#ffffee';
$css['.item']['background-color'] = '#ff9900';

$css['.button']['color'] = 'white';
$css['.button']['background-color'] = '#CC6600';
$css['.button']['border-bottom'] = 'thin solid #222244';
$css['.button']['border-right'] = 'thin solid #222244';
$css['.button']['border-top'] = 'thin solid #9999cc';
$css['.button']['border-left'] = 'thin solid #9999cc';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#bbcbff';

$css['.text']['color'] = 'black';
$css['.text']['background-color'] = '#ffffcc';

$css['.item0']['background-color'] = '#ffeec0';

$css['.item1']['background-color'] = '#ffffee';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#ffeec0';
$css['.listlt']['background-color'] = '#ffffee';

?>
