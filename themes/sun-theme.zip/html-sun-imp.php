<?php
/* 
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 */

$css['.deleted']['background-color'] = '#999999';
$css['.deleted-hi']['background-color'] = '#777777';

$css['.important']['background-color'] = '#ffcccc';
$css['.important-hi']['background-color'] = '#ffaaaa';

$css['.unseen']['background-color'] = '#eecc00';
$css['.unseen-hi']['background-color'] = '#ffcc33';

$css['.answered']['background-color'] = '#ffddaa';
$css['.answered-hi']['background-color'] = '#ffcc99';

$css['.text-hi']['background-color'] = '#ffcc00';
$css['.quoted']['color'] = '#330066';

$css['.folderunsub']['background-color'] = '#bbccdd';
$css['.folderunsub']['font-style'] = 'italic';

?>
