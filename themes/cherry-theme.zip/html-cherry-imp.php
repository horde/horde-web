<?php
/* 
 * $Horde: imp/config/html.php.dist,v 1.16 2001/10/22 09:20:46 jan Exp $
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 */

$css['.deleted']['background-color'] = '#999999';
$css['.deleted-hi']['background-color'] = '#777777';

$css['.important']['background-color'] = '#FFFFAA';
$css['.important-hi']['background-color'] = '#FFFFCC';

$css['.unseen']['background-color'] = '#FFCC99';
$css['.unseen-hi']['background-color'] = '#FFAA99';

$css['.answered']['background-color'] = '#DDDDDD';
$css['.answered-hi']['background-color'] = '#CCCCCC';

$css['.text-hi']['background-color'] = '#EEEEEE';
$css['.quoted']['color'] = '#330066';

$css['.folderunsub']['background-color'] = '#bbccdd';
$css['.folderunsub']['font-style'] = 'italic';

?>
