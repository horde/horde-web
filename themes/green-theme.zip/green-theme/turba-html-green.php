<?php
/*
 * $Horde: turba/config/html.php.dist,v 1.4 2002/02/19 18:00:54 chuck Exp $
 * 
 * CSS properties unique to Turba.
 * This file is parsed by css.php, and used to produce a stylesheet.
 */

$css['.listitem']['background-color'] = '#ffffff';
$css['.listitem-hi']['background-color'] = '#ccccff';
$css['.oldlistitem']['background-color'] = '#cccccc';
$css['.oldlistitem-hi']['background-color'] = '#aaaacc';
