<?php
/* 
 * $Horde: imp/config/html.php.dist,v 1.16.2.1 2002/03/10 03:05:58 chuck Exp $
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 */
$css['.deleted']['background-color'] = '#B82828';
$css['.deleted-hi']['background-color'] = '#B82828';

$css['.important']['background-color'] = '#F78E8E';
$css['.important-hi']['background-color'] = '#ffaaaa';

$css['.unseen']['background-color'] = '#F8DBA9';
$css['.unseen-hi']['background-color'] = '#F4E2C2';

$css['.answered']['background-color'] = '#6FD992';
$css['.answered-hi']['background-color'] = '#97DAAD';

$css['.text-hi']['background-color'] = '#EEC680';

$css['.quoted1']['color'] = '#660066';
$css['.quoted2']['color'] = '#007777';
$css['.quoted3']['color'] = '#990000';
$css['.quoted4']['color'] = '#000099';
$css['.quoted5']['color'] = '#bb6600';

$css['.signature']['color'] = '#cccccc';
$css['.signature-fixed']['color'] = '#cccccc';
$css['.signature-fixed']['font-size'] = '13px';
$css['.signature-fixed']['font-family'] = 'monospace, fixed';

$css['.folderunsub']['background-color'] = '#EDB95E';
$css['.folderunsub']['font-style'] = 'italic';

$css['.quotawarn']['color'] = 'black';
$css['.quotawarn']['background-color'] = 'yellow';

$css['.quotaalert']['color'] = 'white';
$css['.quotaalert']['background-color'] = 'red';


