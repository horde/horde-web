<?php

/* Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * $Horde: horde/config/html.php.dist,v 1.20.2.2 2002/03/09 18:43:36 chuck Exp $
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
$css['body']['background-color'] = '#104E4C';
$css['body']['color'] = 'black';
if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px';
}
$css['body']['scrollbar-base-color'] = '#104E4C';
$css['body']['scrollbar-arrow-color'] = '#136865';
$css['html']['scrollbar-base-color'] = '#104E4C';
$css['html']['scrollbar-arrow-color'] = '#136865';

$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = 'black';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = '#FB9108';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#eeeeff';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = '#FB9108';

$css['a.helpitem']['color'] = '#cccccc';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';

$css['a.widget']['color'] = '#222244';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = 'blue';
$css['a.widget:hover']['background-color'] = '#e9e9e9';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = 'white';
$css['.menu']['background-color'] = '#136865';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color'] = 'white';
$css['.header']['background-color'] = '#136865';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = 'white';

$css['.light']['color'] = 'white';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#ccccee';
$css['.smallheader']['background-color'] = '#136865';
$css['.smallheader']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';
$css['.smallheader:hover']['color'] = 'white';

$css['.small']['color'] = '#AAF7F5';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';

$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = 'black';
$css['.control']['background-color'] = '#FFD368';

$css['.item']['color'] = 'black';
$css['.item']['background-color'] = '#F7E0AA';

$css['.button']['color'] = 'black';
$css['.button']['background-color'] = '#FBA208';
$css['.button']['border-bottom'] = 'thin solid #F7E0AA';
$css['.button']['border-right'] = 'thin solid #F7E0AA';
$css['.button']['border-top'] = 'thin solid #FFD368';
$css['.button']['border-left'] = 'thin solid #FFD368';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#F5C144';

$css['.text']['color'] = 'black';
$css['.text']['background-color'] = 'white';

$css['.item0']['background-color'] = '#f3f3f3';

$css['.item1']['background-color'] = '#e9e9e9';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#CDF6F5';
$css['.listlt']['background-color'] = '#ffffff';


