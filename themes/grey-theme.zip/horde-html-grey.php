<?php

/* Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * $Horde: horde/config/html.php.dist,v 1.20.2.1 2001/11/26 21:43:15 jan Exp $ ?>
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
$css['body']['background-color'] = '#5d5d60';
$css['body']['color'] = 'black';

if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px'; }
$css['body']['scrollbar-base-color'] = '#5d5d60';
$css['body']['scrollbar-arrow-color'] = '#5d5d60';
$css['html']['scrollbar-base-color'] = '#5d5d60';
$css['html']['scrollbar-arrow-color'] = '#5d5d60';

$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = '#595959';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = 'blue';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#9b9b9b';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = 'yellow';

$css['a.helpitem']['color'] = '#9b9b9b';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';

$css['a.widget']['color'] = '';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = 'blue';
$css['a.widget:hover']['background-color'] = '#5d5d60';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = 'white';
$css['.menu']['background-color'] = '#545456';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color'] = '#9f9fa0';
$css['.header']['background-color'] = '#545456';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = 'white';

$css['.light']['color'] = 'white';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#9f9fa0';
$css['.smallheader']['background-color'] = '#545456';
$css['.smallheader']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';

$css['.small']['color'] = '#898993';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';

$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = 'black';
$css['.control']['background-color'] = '#cccccc';

$css['.item']['color'] = 'black';
$css['.item']['background-color'] = '#e9e9e9';

$css['.button']['color'] = 'white';
$css['.button']['background-color'] = '#515163';
$css['.button']['border-bottom'] = 'thin solid #5d5d60';
$css['.button']['border-right'] = 'thin solid #5d5d60';
$css['.button']['border-top'] = 'thin solid #777789';
$css['.button']['border-left'] = 'thin solid #777789';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#c6c6c6';

$css['.text']['color'] = 'black';
$css['.text']['background-color'] = 'white';

$css['.item0']['background-color'] = '#f3f3f3';

$css['.item1']['background-color'] = '#e9e9e9';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#e2e2e2';
$css['.listlt']['background-color'] = '#ffffff';

?>
