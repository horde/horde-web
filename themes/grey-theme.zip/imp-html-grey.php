<?php
/* 
 * $Horde: imp/config/html.php.dist,v 1.16 2001/10/22 09:20:46 jan Exp $
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 */

$css['.deleted']['background-color'] = '#999999';
$css['.deleted-hi']['background-color'] = '#777777';

$css['.important']['background-color'] = '#a56363';
$css['.important-hi']['background-color'] = '#ffaaaa';

$css['.unseen']['background-color'] = '#d3d3d3';
$css['.unseen-hi']['background-color'] = '#ccccff';

$css['.answered']['background-color'] = '#b7ccb7';
$css['.answered-hi']['background-color'] = '#99ee99';

$css['.text-hi']['background-color'] = '#e5e5e5';

$css['.quoted']['color'] = '#330066';

$css['.folderunsub']['background-color'] = '#bbccdd';
$css['.folderunsub']['font-style'] = 'italic';

?>
