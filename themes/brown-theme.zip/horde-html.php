<?php

/* Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * $Horde: horde/config/html.php.dist,v 1.20.2.1 2001/11/26 21:43:15 jan Exp $ ?>
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
$css['body']['background-color'] = '#505050';
$css['body']['color'] = 'black';
if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px';
}
$css['body']['scrollbar-base-color'] = '#505050';
$css['body']['scrollbar-arrow-color'] = '#cfcfbb';
$css['html']['scrollbar-base-color'] = '#505050';
$css['html']['scrollbar-arrow-color'] = '#cfcfbb';

$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = '#505050';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = '#505050';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#505050';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = 'yellow';

$css['a.helpitem']['color'] = '#000000';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';

$css['a.widget']['color'] = '#222244';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = '#505050';
$css['a.widget:hover']['background-color'] = '#ebebd7';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = '#000000';
$css['.menu']['background-color'] = '#cfcfbb';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color'] = '#505050';
$css['.header']['background-color'] = '#cfcfbb';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = 'white';

$css['.light']['color'] = 'white';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#505050';
$css['.smallheader']['background-color'] = '#cfcfbb';
$css['.smallheader']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';

$css['.small']['color'] = '#aaaacc';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';

$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = 'black';
$css['.control']['background-color'] = '#dedebb';

$css['.item']['color'] = 'black';
$css['.item']['background-color'] = '#ebebd7';

$css['.button']['color'] = 'white';
$css['.button']['background-color'] = '#505050';
$css['.button']['border-bottom'] = 'thin solid #222244';
$css['.button']['border-right'] = 'thin solid #222244';
$css['.button']['border-top'] = 'thin solid #cfcfbb';
$css['.button']['border-left'] = 'thin solid #dedebb';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#cdcdcd';

$css['.text']['color'] = 'black';
$css['.text']['background-color'] = 'white';

$css['.item0']['background-color'] = '#f3f3f3';

$css['.item1']['background-color'] = '#e6e6de';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#E6E6DE';
$css['.listlt']['background-color'] = '#ffffff';

?>
