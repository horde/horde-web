<?php
      
/*
 *
 * Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * Theme by : Eric Jon Rostetter <eric.rostetter@physics.utexas.edu>
 * Please contact the Theme's author for any missing style.
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
$css['body']['background-color'] = '#F0B040';
$css['body']['background-color'] = '#F0B060';
$css['body']['color'] = 'black';
if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px';
}
$css['body']['scrollbar-base-color'] = '#E88B65';
$css['body']['scrollbar-base-color'] = '#666699';
$css['body']['scrollbar-arrow-color'] = 'white';
$css['body']['scrollbar-arrow-color'] = '#ddddff';
$css['html']['scrollbar-base-color'] = '#E88B65';
$css['html']['scrollbar-base-color'] = '#666699';
$css['html']['scrollbar-arrow-color'] = 'white';
$css['html']['scrollbar-arrow-color'] = '#ddddff';

$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = '#333399';
$css['a']['color'] = '#cc6600';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = 'black';
$css['a:hover']['color'] = '#cc6600';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#EEEEFF';
$css['a.menuitem']['background'] = '#cc6600';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = 'yellow';

$css['a.helpitem']['color'] = '#CCCCCC';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';

$css['a.widget']['color'] = '#222244';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = 'blue';
//$css['a.widget:hover']['background-color'] = 'blue';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = 'white';
$css['.menu']['background-color'] = '#E37445';
$css['.menu']['background-color'] = '#cc6600';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color'] = '#000000';
$css['.header']['color'] = '#ffffff';
$css['.header']['background-color'] = '#E37445';
$css['.header']['background-color'] = '#E09000';
$css['.header']['background-color'] = '#cc6600';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = 'white';

$css['.light']['color'] = 'white';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#000000';
$css['.smallheader']['color'] = '#ffffff';
$css['.smallheader']['background-color'] = '#E37445';
$css['.smallheader']['background-color'] = '#cc6600';
$css['.smallheader']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';
$css['.smallheader:hover']['color'] = 'white';

$css['.small']['color'] = '#aaaacc';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';

$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = 'black';
$css['.control']['background-color'] = '#E7C5B6';
$css['.control']['background-color'] = '#cccccc';
$css['.control']['background-color'] = '#f9ce8a';

$css['.item']['color'] = 'black';
$css['.item']['background-color'] = '#E7BEAD';
$css['.item']['background-color'] = '#e9e9e9';

$css['.button']['color'] = 'white';
$css['.button']['background-color'] = '#E37445';
$css['.button']['background-color'] = '#cc6600';
$css['.button']['border-bottom'] = 'thin solid #A94419';
$css['.button']['border-bottom'] = 'thin solid #222244';
$css['.button']['border-right'] = 'thin solid #A94419';
$css['.button']['border-right'] = 'thin solid #222244';
$css['.button']['border-top'] = 'thin solid #F1B69D';
$css['.button']['border-top'] = 'thin solid #9999cc';
$css['.button']['border-left'] = 'thin solid #F1B69D';
$css['.button']['border-left'] = 'thin solid #9999cc';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#cc6600';

$css['.text']['color'] = 'black';
$css['.text']['background-color'] = 'white';

$css['.item0']['background-color'] = '#F3F3F3';

$css['.item1']['background-color'] = '#E9E9E9';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#F0F0FF';
$css['.listlt']['background-color'] = '#FFFFFF';
