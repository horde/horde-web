<?php

/*
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * Theme by : Eric Jon ROSTETTER <eric.rostetter@physics.utexas.edu>
 * Please contact the Theme's author for any missing style.
 */

$css['.deleted']['background-color'] = '#cccccc';
$css['.deleted-hi']['background-color'] = '#777777';
$css['.deleted-hi']['background-color'] = '#888888';

$css['.important']['background-color'] = 'yellow';
$css['.important-hi']['background-color'] = '#ffbbbb';

$css['.unseen']['background-color'] = '#ffddee';
$css['.unseen']['background-color'] = '#ddffdd';
$css['.unseen-hi']['background-color'] = '#c4ffc4';

$css['.answered']['background-color'] = '#eeeea0';
$css['.answered-hi']['background-color'] = '#eeee80';

$css['.text-hi']['background-color'] = '#e7e7e7';

$css['.quoted1']['color'] = '#660066';
$css['.quoted2']['color'] = '#007777';
$css['.quoted3']['color'] = '#990000';
$css['.quoted4']['color'] = '#000099';
$css['.quoted5']['color'] = '#bb6600';

$css['.signature']['color'] = '#cccccc';
$css['.signature-fixed']['color'] = '#cccccc';
$css['.signature-fixed']['font-size'] = '13px';
$css['.signature-fixed']['font-family'] = 'monospace, fixed';

$css['.folderunsub']['background-color'] = '#bbccdd';
$css['.folderunsub']['font-style'] = 'italic';

$css['.quotawarn']['color'] = 'black';
$css['.quotawarn']['background-color'] = 'yellow';
$css['.quotawarn']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.quotawarn']['font-weight'] = 'bold';
$css['.quotawarn']['font-size'] = '17px';

$css['.quotaalert']['color'] = 'white';
$css['.quotaalert']['background-color'] = 'red';
$css['.quotaalert']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.quotaalert']['font-weight'] = 'bold';
$css['.quotaalert']['font-size'] = '17px';
