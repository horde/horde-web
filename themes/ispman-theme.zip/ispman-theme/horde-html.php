<?php

/* Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * $Horde: horde/config/html.php.dist,v 1.23 2001/11/26 21:37:56 jan Exp $ ?>
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
$css['body']['background-color'] = '#b8d8f1';
$css['body']['color'] = 'black';
if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px';
}
$css['body']['scrollbar-base-color'] = '#666699';
$css['body']['scrollbar-arrow-color'] = '#ddddff';
$css['html']['scrollbar-base-color'] = '#666699';
$css['html']['scrollbar-arrow-color'] = '#ddddff';

$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = '#333399';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = 'blue';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#eeeeff';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = 'yellow';

$css['a.helpitem']['color'] = '#cccccc';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';

$css['a.widget']['color'] = '#222244';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = 'blue';
$css['a.widget:hover']['background-color'] = '#e9e9e9';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = 'white';
$css['.menu']['background-color'] = '#000000';
$css['.menu']['background-image'] = 'url(/horde/graphics/blue-background.gif)';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color'] = '#FFFFFF';
$css['.header']['background-color'] = '#6ba5de';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = 'white';

$css['.light']['color'] = 'white';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#FFFFFF';
$css['.smallheader']['background-color'] = '#6ba5de';
$css['.smallheader']['font-size'] = '12px';

$css['.small']['color'] = '#aaaacc';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';

$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = 'black';
$css['.control']['background-color'] = '#cccccc';

$css['.item']['color'] = 'black';
$css['.item']['background-color'] = '#e9e9e9';

$css['.button']['color'] = '#FFFFFF';
$css['.button']['background-color'] = '#666699';
$css['.button']['background-image'] = 'url(/horde/graphics/blue-background.gif)';
$css['.button']['border-bottom'] = 'thin solid #222244';
$css['.button']['border-right'] = 'thin solid #222244';
$css['.button']['border-top'] = 'thin solid #9999cc';
$css['.button']['border-left'] = 'thin solid #9999cc';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#bbcbff';

$css['.text']['color'] = 'black';
$css['.text']['background-color'] = 'white';

$css['.item0']['background-color'] = '#f3f3f3';

$css['.item1']['background-color'] = '#e9e9e9';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#f0f0ff';
$css['.listlt']['background-color'] = '#ffffff';

?>
