<?php

      /* Base Horde CSS properties.
       * 
       * This file is parsed by css.php, and used to produce a stylesheet.
       */
      
$css['body']['font-family']='Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size']='12px';
$css['body']['background-color']='#1F2E1B';
$css['body']['color']='#000000';

if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px'; }
$css['body']['scrollbar-base-color'] = '#5d5d60';
$css['body']['scrollbar-arrow-color'] = '#5d5d60';
$css['html']['scrollbar-base-color'] = '#5d5d60';
$css['html']['scrollbar-arrow-color'] = '#5d5d60';

$css['input']['font-family']='Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size']='12px';

$css['a']['color']='#333366';
$css['a']['font-family']='Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size']='12px';
$css['a']['text-decoration']='none';
$css['a:hover']['color'] = 'blue';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color']='#ffffff';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';

$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['background-color']='#222244';

$css['a.helpitem']['color'] = '#9b9b9b';

$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = 'yellow';
$css['a.widget']['color'] = '';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';

$css['a.widget:hover']['background-color']='#999966';

$css['a.widget']['color']='#0a2912';

$css['.outline']['background-color']='black';

$css['.menu']['background-image'] = 'url(' . $registry->getParam('graphics', 'horde') . '/camouflage.gif)';
$css['.menu']['color']='#ffffff';
$css['.menu']['background-color']='#1F2E1B';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color']='#999966';
$css['.header']['background-color']='#293d22';
$css['.header']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.header']['font-size'] = '17px';

$css['.light']['color']='white';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color']='#171AEE';
$css['.smallheader']['background-color']='#FFFFFF';
$css['.smallheader']['font-family']='Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';

$css['.small']['color']='#aaaacc';
$css['.small']['font-family']='Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';
$css['.legend']['color'] = '#000000';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color']='black';
$css['.control']['background-color']='#999966';

$css['a.control']['color']='#00ff00';

$css['.item']['color']='white';
$css['.item']['background-color']='#99993E';

$css['.button']['color']='white';
$css['.button']['background-color']='#666699';
$css['.button']['border-bottom']='thin solid #222244';
$css['.button']['border-right']='thin solid #222244';
$css['.button']['border-top']='thin solid #9999cc';
$css['.button']['border-left']='thin solid #9999cc';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['.button']['font-weight']='bold';

$css['.selected']['background-color']='#999966';

$css['.text']['background-color']='white';

$css['.item0']['background-color']='#f3f3f3';

$css['.item1']['background-color']='#e9e9e9';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family']='monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family']='Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family']='Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color']='#f0f0ff';

$css['.listlt']['background-color']='#ffffff';



?>
