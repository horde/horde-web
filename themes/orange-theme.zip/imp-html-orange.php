<?php

/*
 * $Horde$
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * Theme by : Ronnie Garcia <ronnie@mk2.net>
 * Please contact the Theme's author for any missing style.
 */

$css['.deleted']['background-color'] = '#999999';
$css['.deleted-hi']['background-color'] = '#777777';

$css['.important']['background-color'] = '#ffcccc';
$css['.important-hi']['background-color'] = '#ffbbbb';

$css['.unseen']['background-color'] = '#ffeeee';
$css['.unseen-hi']['background-color'] = '#ffdddd';

$css['.answered']['background-color'] = '#eeffcc';
$css['.answered-hi']['background-color'] = '#eeeebb';

$css['.text-hi']['background-color'] = '#e7e7e7';

$css['.quoted1']['color'] = '#660066';
$css['.quoted2']['color'] = '#007777';
$css['.quoted3']['color'] = '#990000';
$css['.quoted4']['color'] = '#000099';
$css['.quoted5']['color'] = '#bb6600';

$css['.signature']['color'] = '#cccccc';
$css['.signature-fixed']['color'] = '#cccccc';
$css['.signature-fixed']['font-size'] = '13px';
$css['.signature-fixed']['font-family'] = 'monospace, fixed';

$css['.folderunsub']['background-color'] = '#bbccdd';
$css['.folderunsub']['font-style'] = 'italic';

$css['.quotawarn']['color'] = 'black';
$css['.quotawarn']['background-color'] = 'yellow';

$css['.quotaalert']['color'] = 'white';
$css['.quotaalert']['background-color'] = 'red';
