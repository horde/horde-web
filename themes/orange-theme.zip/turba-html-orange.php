<?php
/*
 * $Horde$
 *
 * CSS properties unique to Turba.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * Theme by : Ronnie Garcia <ronnie@mk2.net>
 * Please contact the Theme's author for any missing style.
 */

$css['.listitem']['background-color'] = '#ffeeee';
$css['.listitem-hi']['background-color'] = '#ffdddd';
$css['.oldlistitem']['background-color'] = '#999999';
$css['.oldlistitem-hi']['background-color'] = '#777777';
