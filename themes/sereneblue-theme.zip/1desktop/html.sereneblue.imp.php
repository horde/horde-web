<?php
/* 
 * $Horde: imp/config/html.php.dist,v 1.16 2001/10/22 09:20:46 jan Exp $
 *
 * CSS properties unique to IMP.
 * This file is parsed by css.php, and used to produce a stylesheet.
 */

$css['.deleted']['background-color'] = '#cccccc';
$css['.deleted-hi']['background-color'] = '#999999';

$css['.important']['background-color'] = '#FFFFAA';
$css['.important-hi']['background-color'] = '#FFFFCC';

$css['.unseen']['background-color'] = '#eeeeff';
$css['.unseen-hi']['background-color'] = '#ccccff';

$css['.answered']['background-color'] = '#CCFFFF';
$css['.answered-hi']['background-color'] = '#CCDDDD';

$css['.text-hi']['background-color'] = '#EEEEEE';
$css['.quoted']['color'] = '#330066';

$css['.folderunsub']['background-color'] = '#003366';
$css['.folderunsub']['font-style'] = 'italic';

?>
