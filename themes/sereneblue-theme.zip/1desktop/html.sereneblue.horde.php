<?php

/* Base Horde CSS properties.
 * This file is parsed by css.php, and used to produce a stylesheet.
 *
 * $Horde: horde/config/html.php.dist,v 1.20.2.1 2001/11/26 21:43:15 jan Exp $ ?>
 */

$css['body']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['body']['font-size'] = '12px';
$css['body']['background-color'] = '#eeeeee';
$css['body']['color'] = '#333366';
if ($browser->hasQuirk('scrollbar_in_way')) {
    $css['body']['margin-right'] = '15px';
}
/*
// scrollbar colors: IE custom stuff. dump.
$css['body']['scrollbar-base-color'] = '#5d5d60';
$css['body']['scrollbar-arrow-color'] = '#ddddff';
$css['html']['scrollbar-base-color'] = '#4d5d60';
$css['html']['scrollbar-arrow-color'] = '#ddddff';
*/
$css['input']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['input']['font-size'] = '12px';

$css['form']['margin'] = '0px';

$css['a']['color'] = '#000066';
$css['a']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['a']['font-size'] = '12px';
$css['a']['text-decoration'] = 'none';
$css['a:hover']['color'] = '#333399';
$css['a:hover']['text-decoration'] = 'underline';

$css['a.menuitem']['color'] = '#333366';
$css['a.menuitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.menuitem']['font-size'] = '11px';
$css['a.menuitem']['font-weight'] = 'normal';
$css['a.menuitem:hover']['color'] = '#333399';

$css['a.helpitem']['color'] = '#333366';
$css['a.helpitem']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.helpitem']['font-size'] = '12px';
$css['a.helpitem']['font-weight'] = 'normal';
$css['a.helpitem:hover']['color'] = '#666699';

$css['a.widget']['color'] = '#333333';
$css['a.widget']['font-family'] = 'Verdana,Helvetica,sans-serif';
$css['a.widget']['font-size'] = '11px';
$css['a.widget:hover']['color'] = '#0066ff';

$css['.outline']['background-color'] = 'black';

$css['.menu']['color'] = '#333366';
$css['.menu']['background-color'] = '#ccccdd';
$css['.menu']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.header']['color'] = '#333366';
$css['.header']['background-color'] = '#ccccdd';
$css['.header']['font-weight'] = 'bold';
$css['.header']['font-size'] = '17px';
$css['.header:hover']['color'] = '#333366';

$css['.light']['color'] = '#666699';
$css['.light']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.light']['font-size'] = '12px';

$css['.smallheader']['color'] = '#333366';
$css['.smallheader']['background-color'] = '#ccccdd';
$css['.smallheader']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.smallheader']['font-size'] = '12px';

$css['.small']['color'] = '#FFFFFF';
$css['.small']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.small']['font-size'] = '11px';
$css['a.small:hover']['color'] = '#FFFFFF';
$css['a.small:hover']['text-decoration'] = 'underline';

$css['.legend']['color'] = '#333366';
$css['.legend']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';
$css['.legend']['font-size'] = '11px';

$css['.control']['color'] = '#333366';
$css['.control']['background-color'] = '#ddddee';

$css['.item']['color'] = '#333366';
$css['.item']['background-color'] = '#ddddee';

$css['.button']['color'] = '#333366';
$css['.button']['background-color'] = '#cccccc';
$css['.button']['border-bottom'] = 'thin solid #222244';
$css['.button']['border-right'] = 'thin solid #222244';
$css['.button']['border-top'] = 'thin solid #9999cc';
$css['.button']['border-left'] = 'thin solid #9999cc';
$css['.button']['font-size'] = '11px';
$css['.button']['font-family'] = 'Verdana,Helvetica,sans-serif';

$css['.selected']['background-color'] = '#aaaacc';

$css['.text']['color'] = '#333366';
$css['.text']['background-color'] = '#FFFFFF';

$css['.item0']['background-color'] = '#CCCCee';

$css['.item1']['background-color'] = '#eeeeee';

$css['.fixed']['font-size'] = '13px';
$css['.fixed']['font-family'] = 'monospace, fixed';

$css['td']['font-size'] = '12px';
$css['td']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['th']['font-size'] = '12px';
$css['th']['font-family'] = 'Geneva,Arial,Helvetica,sans-serif';

$css['.list']['background-color'] = '#ddddff';
$css['.listlt']['background-color'] = '#ccccee';

?>
